function error(){
document.getElementById("wrong").innerHTML="NIM atau Password Salah";
}