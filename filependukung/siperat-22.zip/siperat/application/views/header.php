<!DOCTYPE html>
<html>
<head>
	<title>BEM FILKOM UB</title>
	<meta name="Resource-type" content="Document" />
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
	<link rel="icon" href="http://bem.filkom.ub.ac.id/cms/new/aYajIwaRbSaTisrEvInUreTupMoKuMLiSaTlUKaf4102IsAmROfNiMeTSisIrKIFilaHEloTAubIDiniEtiSBeW/wp-content/uploads/2017/04/logo-min-100x100.png" sizes="32x32">
 	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/0.98.2/css/materialize.min.css">
	<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
</head>
<body>