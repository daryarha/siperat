	<script type="text/javascript" src="https://code.jquery.com/jquery-2.1.1.min.js"></script>
	<script type="text/javascript" src=" http://materializecss.com/templates/starter-template/js/init.js"></script>
  	<script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/0.98.2/js/materialize.min.js"></script>
	<script type="text/javascript">
	    $(document).ready(function(){
	      $('.modal').modal();
	      $('select').material_select();
	    });       
	</script>
<footer style=" color: rgb(38, 166, 154);text-align: center; font-size: 10pt; margin-top: 50px">Developed by<br><a href="http://bem.filkom.ub.ac.id/anggota/" style="color: #26a69a"> <b>Implementasi Keilmuan</b></a></footer>
</body>
</html>