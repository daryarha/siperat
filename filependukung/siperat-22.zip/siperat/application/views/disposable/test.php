<!DOCTYPE html>
<html>
<head>
 <title></title>
</head>
<body>
 <h1>Selamat Datang</h1>
 <p>Ini tampilan dari view hello_ci</p>
 <?php echo $nama; ?>
 <?php echo $alamat; ?>
 <?php echo $kampus; ?>
</body>
</html>