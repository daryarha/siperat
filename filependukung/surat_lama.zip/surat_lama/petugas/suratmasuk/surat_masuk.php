<?php ?>
<head>
    <link rel="stylesheet" href="../../tablesorter/style.css" type="text/css" media="print, projection, screen" />
    <script type="text/javascript" src="../../tablesorter/jquery-latest.js"></script>
    <script type="text/javascript" src="../../tablesorter/jquery.tablesorter.js"></script>
    <script type="text/javascript" src="../../tablesorter/jquery.tablesorter.pager.js"></script>

    <script type="text/javascript">
        $(function() {
            $("table")
            .tablesorter({widthFixed: true, widgets: ['zebra'],
                headers: {
                    // assign the secound column (we start counting zero)
                    10: {
                        // disable it by setting the property sorter to false
                        sorter: false
                    }
                }})
            .tablesorterPager({container: $("#pager"),positionFixed: false });
        });
    </script>
    <script type="text/javascript">

        function conf(){
            if(confirm("Anda Yakin ?")){
                return true;

            }else{
                window.close();
                return false;
            }
        }
    </script>
</head>
<body>
<center><h2>Data Surat Masuk</h2>
    <hr>
    <b><a href=?page=inputSuratMasuk>Insert Data</a></b></center>
<?php
include '../../connection.php';
$sql = "SELECT a. id_surat_masuk as idSuratMasuk, a.tanggal as tanggal, a.no_surat_masuk as kodeSuratMasuk, c.keterangan as pengirim, b.keterangan as jenisSurat,a.perihal, a.lampiran, a.tindakan, a.keterangan, d.nama_jenis_pengirim as jenisPengirim
FROM tabel_surat_masuk a, tabel_jenis_surat b, tabel_pengirim c, tabel_jenis_pengirim d
WHERE a.id_jenis_surat = b.id_jenis_surat
AND a.id_pengirim = c.id_pengirim
AND c.id_jenis_pengirim = d.id_jenis_pengirim;";
$query = mysql_query($sql) or die(mysql_error());
$no = 1;
if (mysql_num_rows($query) > 0) {
    ?>
    <table class="tablesorter" cellspacing="1">
        <thead>
            <tr>
                <th>No</th>
                <th>Tanggal</th>
                <th>No Surat</th>
                <th>Jen. Pengirim</th>
                <th>Pengirim</th>
                <th>Jenis Surat</th> 
                <th>Perihal</th>                
                <th>Lampiran</th>                
                <th>Tindakan</th>                
                <th>Keterangan</th>
                <th colspan="2">Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php
            while ($row = mysql_fetch_object($query)) {
                ?>
                <tr>
                    <td><?php echo $no++ ?></td>
                    <td><?php echo $row->tanggal; ?></td>
                    <td><?php echo $row->kodeSuratMasuk; ?></td>
                    <td><?php echo $row->jenisPengirim; ?></td>
                    <td><?php echo $row->pengirim; ?></td>
                    <td><?php echo $row->jenisSurat; ?></td>
                    <td><?php echo $row->perihal; ?></td>
                    <td><?php echo $row->lampiran; ?></td>
                    <td><?php echo $row->tindakan; ?></td>
                    <td><?php echo $row->keterangan; ?></td>
                    <td><a href='?page=updateSuratMasuk&kdupd=<?= $row->idSuratMasuk ?>'><img src="../../img/edit.png" width="25" height="25"></a></td>
                    <td><a href='?page=prosesSuratMasuk&kddel=<?= $row->idSuratMasuk ?>' onclick="return conf();"><img src="../../img/delete.png" width="25" height="25"></a></td>
                </tr>
                <?php
            }
            ?>
        </tbody>

    </table>
    <div id="pager" class="pager" align="">
        <form>
            <img src="../../tablesorter/img/first.gif" class="first"/>
            <img src="../../tablesorter/img/prev.gif" class="prev"/>
            <input type="text" class="pagedisplay"/>
            <img src="../../tablesorter/img/next.gif" class="next"/>
            <img src="../../tablesorter/img/last.gif" class="last"/>
            <select class="pagesize">
                <option value="10" selected="selected">10</option>

                <option value="20">20</option>
                <option value="30">30</option>
                <option  value="40">40</option>
                <option  value="50">50</option>
                <option  value="100">100</option>
            </select>
        </form>
    </div>
    <center><a href='../../logout.php'>Logout</a></center>
    </body>
    <?php
} else {
    echo "<br>";
    echo "<center>";
    echo "Data tidak ada<br>";
    echo "<a href='../../logout.php'>Logout</a>";
    echo "</center>";
}
?>