<?php

session_start();
if (!isset($_SESSION['username'])) {
    ?>
    <script type="text/javascript">document.location='../../index.php'</script>
    <?php

}
if ($_SESSION['id_priv'] != 3) {
    echo "<script type='text/javascript'>history.go(-1);</script>";
}
?>

<?php

if (isset($_GET['page'])) {
    $page = $_GET['page'];
    if ($page == "index") {
        include 'surat_masuk.php';
    } else if ($page == "inputSuratMasuk") {
        include 'form_surat_masuk.php';
    } else if ($page == "prosesSuratMasuk") {
        include 'proses_surat_masuk.php';
    } else if ($page == "updateSuratMasuk") {
        include 'update_surat_masuk.php';
    } else {
        echo "<script>
            
            document.location='?page=index';
        </script>";
    }
} else {
    echo "<script>
            
            document.location='?page=index';
        </script>";
}
?>

