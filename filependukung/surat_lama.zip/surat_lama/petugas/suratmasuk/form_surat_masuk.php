<?php
include "../../connection.php";
?>
<head>

    <link rel="stylesheet" href="../../validasi/jquery.validationEngine.jquery.css" type="text/css" media="screen" />
    <script src="../../validasi/js/jquery.js" type="text/javascript"></script>
    <script src="../../validasi/jquery.validationEngine-en.js" type="text/javascript"></script>
    <script src="../../validasi/jquery.validationEngine.js" type="text/javascript"></script>
    <link rel="stylesheet" href="../themes/base/jquery.ui.all.css">
<!--    <script src="../jquery-1.4.4.js"></script>-->
    <script src="../ui/jquery.ui.core.js"></script>
    <script src="../ui/jquery.ui.widget.js"></script>
    <script src="../ui/jquery.ui.datepicker.js"></script>
    <script>
        $(document).ready(function() {
            $("#formID").validationEngine()
        });
    </script>
    <script>
        $(function() {
            //$( "#datepicker" ).datepicker();
            $( "#datepicker" ).datepicker( {dateFormat:"yy-mm-dd",changeMonth: true,
                changeYear: true} );
           
        });
    </script>
    <script type="text/javascript">
        var xmlHttp= buatObjekXmlHttp();
        function buatObjekXmlHttp()
        {
            var obj = null;
            if (window.ActiveXObject)
                obj = new ActiveXObject ("Microsoft.XMLHTTP");
            else
                if (window.XMLHttpRequest)
                    obj = new XMLHttpRequest();
            //cek isi xmlHttp
            if (obj == null)
                document.write("Browser tidak mendukung ajax");
            return obj;
        }

        function ambilData(sumber_data, id_elemen)
        {
            if (xmlHttp!= null) //jika object xmlHttp sudah terbentuk
            {
                var obj = document.getElementById(id_elemen);  //memasukkan nilai id_elemen ke dalam object var
                xmlHttp.open("GET", sumber_data);//untuk menyiapkan permintaan ke server metodenya ada dua GET dan POST, sumber_data-> URL

                xmlHttp.onreadystatechange = function () //status server
                {
                    if (xmlHttp.readyState == 4) //jika 4 berarti permintaan komplit  ... 4 adalah sudah ketentuan
                    {

                        if (xmlHttp.status == 200) // 200 untuk status OK , 404 untuk status not found
                        {
                            obj.innerHTML = xmlHttp.responseText;
                        }
                        else obj.innerHTML = "Error. Status: " + xmlHttp.status;
                    }
                    else //jika  xmlHttp.readyState masih bukan = 4 , jalankan gambar dibawah ... dengan kata lain permintaan belum selesai

                    obj.innerHTML = "<img src='loading.gif' />"; //gambar loading ... bisa didownload di internet banyak ko ... googling aja

            }
            xmlHttp.send(null); //untuk mengirim permintaan ke server
        }
    }
    function prosesData(sumber_data, id_elemen)

    {

        var id_jenis_pengirim = document.getElementById("jenis_pengirim");

        var elemen_id_jenis_pengirim = id_jenis_pengirim[id_jenis_pengirim.selectedIndex];

        var nilai_id_jenis_pengirim = elemen_id_jenis_pengirim.value;


        var url= sumber_data + "?id_jenis_pengirim=" + nilai_id_jenis_pengirim;

        var a = document.getElementById("txtPengirim");
               
        ambilData(url,id_elemen);
    }
    </script>
</head>
<body>
<center>
    <form action="?page=prosesSuratMasuk" method="POST" id="formID" class="formular">
        <table>
            <tr>
                <td colspan="5" align="center" cellpadding="3" ><font size="5"><b>Data Surat Masuk</b></font></td>
            </tr>
            <tr>
                <td>Nomor Surat</td>
                <td>:</td>
                <td colspan="3"><input type="text" size="55" placeholder="input nomor surat" id="no_surat"  class="validate[required,maxSize[13]] text-input" name="no_surat"></td>
            </tr>
            <tr>
                <td>Tanggal</td>
                <td>:</td>
                <td><input type="text" name ="tanggal"id="datepicker" placeholder="input tanggal" class="validate[required]">
                </td>
            </tr>
            <tr>
                <td>Jenis Pengirim </td>
                <td>:</td>
                <td colspan="3">
                    <select name="jenis_pengirim" id="jenis_pengirim" onchange="prosesData('prosesAjax.php','pengirim')" class="validate[required]">
                        <option value="">Pilih Jenis Pengirim</option>
                        <?php
                        $query = "select * from tabel_jenis_pengirim";
                        $sql = mysql_query($query) or die(mysql_error());
                        while ($row = mysql_fetch_object($sql)) {
                            echo "<option value='$row->id_jenis_pengirim'>$row->nama_jenis_pengirim</option>";
                        }
                        ?>
                    </select>

                </td>
            </tr>
            <tr>
                <td>Pengirim</td>
                <td>:</td>
                <td colspan="3">
                    <div id="pengirim" ></div>    
                </td>
            </tr>
            <tr>
                <td>Jenis Surat</td>
                <td>:</td>
                <td colspan="3">
                    <select name="jenis_surat" id="jenis_surat" class="validate[required]">
                        <option value="">Pilih Jenis Surat</option>
                        <?php
                        $query = "select * from tabel_jenis_surat";
                        $sql = mysql_query($query) or die(mysql_error());
                        while ($row = mysql_fetch_object($sql)) {
                            echo "<option value='$row->id_jenis_surat'>$row->keterangan</option>";
                        }
                        ?>
                    </select>
                </td>
            </tr>
            <tr>
                <td>Perihal</td>
                <td>:</td>
                <td colspan="3"><input type="text" placeholder="input perihal" id="perihal" name="perihal"size="55" class="validate[required] text-input"/></td>
            </tr>
            <tr>
                <td>Lampiran</td>
                <td>:</td>
                <td colspan="3"><input type="text" placeholder="input lampiran"id="lampiran" name="lampiran" size="55"/></td>
            </tr> 
            <tr>
                <td>Tindakan</td>
                <td>:</td>
                <td colspan="3">
                    <input type="radio" name="tindakan" value="Tidak Dibalas">Tidak Dibalas &nbsp;
                    <input type="radio" name="tindakan" value="Dibalas">Dibalas
                </td>
            </tr>
            <tr>
                <td>Keterangan</td>
                <td>:</td>
                <td colspan="3"><textarea style="width: 339px" id="keterangan" name="keterangan"placeholder="input keterangan"></textarea></td>
            </tr>
            <tr>
                <td colspan="5" align="center">
                    <input type="submit" value="Submit"/>
                    <input type="reset" value="Reset"/>
                </td>
            </tr>
        </table>
    </form>
    <br>
    <a href="index.php">Lihat Data</a>
</center>
</body>