<?php
include '../../connection.php';
if (isset($_POST['no_surat'])) {
    $no_surat = $_POST['no_surat'];
} else {
    $no_surat = "";
}
if (isset($_POST['tanggal'])) {
    $tanggal = $_POST['tanggal'];
} else {
    $tanggal = "";
}
if (isset($_POST['jenis_pengirim'])) {
    $jenis_pengirim = $_POST['jenis_pengirim'];
} else {
    $jenis_pengirim = "";
}
if (isset($_POST['pengirim'])) {
    $pengirim = $_POST['pengirim'];
} else {
    $pengirim = "";
}

if (isset($_POST['jenis_surat'])) {
    $jenis_surat = $_POST['jenis_surat'];
} else {
    $jenis_surat = "";
}
if (isset($_POST['perihal'])) {
    $perihal = $_POST['perihal'];
} else {
    $perihal = "";
}

if (isset($_POST['lampiran'])) {
    $lampiran = $_POST['lampiran'];
} else {
    $lampiran = "";
}
if (isset($_POST['tindakan'])) {
    $tindakan = $_POST['tindakan'];
} else {
    $tindakan = "";
}
if (isset($_POST['keterangan'])) {
    $keterangan = $_POST['keterangan'];
} else {
    $keterangan = "";
}
if (isset($_POST['kdupd'])) {
    $kdupd = $_POST['kdupd'];
} else {
    $kdupd = "";
}

if (isset($_GET['kddel'])) {
    $kddel = $_GET['kddel'];
} else {
    $kddel = "";
}

$res = mysql_query("select max(id_surat_masuk) as max from tabel_surat_masuk") or die(mysql_error());
$r = mysql_fetch_array($res);
$idsm = $r['max'] + 1;

if (($kdupd == "") && ($kddel == "")) {
    if ($jenis_pengirim != 1) {
        $qu = mysql_query("select max(id_pengirim) as max from tabel_pengirim") or die(mysql_error());
        $r = mysql_fetch_array($qu);
        $id_pengirim = $r['max'] + 1;

        $que = mysql_query("SELECT id_pengirim FROM tabel_pengirim WHERE keterangan = '$pengirim' AND id_jenis_pengirim =$jenis_pengirim")
                or die(mysql_error());
        $re = mysql_fetch_array($que);
        $cek_id = $re['id_pengirim'];

        if ($cek_id == null) {
            mysql_query("insert into tabel_pengirim(id_pengirim,kode_pengirim,keterangan,id_jenis_pengirim)
            values($id_pengirim,'','$pengirim',$jenis_pengirim)") or die(mysql_error());

            $query = "INSERT into 
        tabel_surat_masuk(id_surat_masuk,no_surat_masuk,id_jenis_surat,id_pengirim,tanggal,perihal,lampiran,tindakan,keterangan)
        VALUES($idsm,'$no_surat',$jenis_surat,$id_pengirim,'$tanggal','$perihal','$lampiran','$tindakan','$keterangan')";
        } else {
            $query = "INSERT into 
        tabel_surat_masuk(id_surat_masuk,no_surat_masuk,id_jenis_surat,id_pengirim,tanggal,perihal,lampiran,tindakan,keterangan)
        VALUES($idsm,'$no_surat',$jenis_surat,$cek_id,'$tanggal','$perihal','$lampiran','$tindakan','$keterangan')";
        }
    } else if ($jenis_pengirim == 1) {
        $query = "INSERT into 
        tabel_surat_masuk(id_surat_masuk,no_surat_masuk,id_jenis_surat,id_pengirim,tanggal,perihal,lampiran,tindakan,keterangan)
        VALUES($idsm,'$no_surat',$jenis_surat,$pengirim,'$tanggal','$perihal','$lampiran','$tindakan','$keterangan')";
    }
    mysql_query($query) or die(mysql_error());
}
if ($kdupd != "") {
    if ($jenis_pengirim != 1) {
        $qu = mysql_query("select max(id_pengirim) as max from tabel_pengirim") or die(mysql_error());
        $r = mysql_fetch_array($qu);
        $id_pengirim = $r['max'] + 1;

        $que = mysql_query("SELECT id_pengirim FROM tabel_pengirim WHERE keterangan = '$pengirim' AND id_jenis_pengirim =$jenis_pengirim")
                or die(mysql_error());
        $re = mysql_fetch_array($que);
        $cek_id = $re['id_pengirim'];

        if ($cek_id == null) {
            mysql_query("insert into tabel_pengirim(id_pengirim,kode_pengirim,keterangan,id_jenis_pengirim)
            values($id_pengirim,'','$pengirim',$jenis_pengirim)") or die(mysql_error());

            $query = "update tabel_surat_masuk set no_surat_masuk='$no_surat', id_jenis_surat=$jenis_surat, id_pengirim=$id_pengirim,tanggal='$tanggal',perihal='$perihal',lampiran='$lampiran',tindakan='$tindakan',keterangan='$keterangan' where id_surat_masuk=$kdupd";
        } else {
            $query = "update tabel_surat_masuk set no_surat_masuk='$no_surat', id_jenis_surat=$jenis_surat, id_pengirim=$cek_id,tanggal='$tanggal',perihal='$perihal',lampiran='$lampiran',tindakan='$tindakan',keterangan='$keterangan' where id_surat_masuk=$kdupd";
        }
    } else if ($jenis_pengirim == 1) {
        $query = "update tabel_surat_masuk set no_surat_masuk='$no_surat', id_jenis_surat=$jenis_surat, id_pengirim=$pengirim,tanggal='$tanggal',perihal='$perihal',lampiran='$lampiran',tindakan='$tindakan',keterangan='$keterangan' where id_surat_masuk=$kdupd";
    }
    mysql_query($query) or die(mysql_error());
}
if ($kddel != "") {

    $que = mysql_query("select id_pengirim from tabel_surat_masuk where id_surat_masuk=$kddel");
    $uh = mysql_fetch_array($que);
    $userhapus = $uh['id_pengirim'];

    $q = mysql_query("select id_jenis_pengirim from tabel_pengirim where id_pengirim = $userhapus");
    $u = mysql_fetch_array($q);
    $js = $u['id_jenis_pengirim'];

    if ($js != 1) {        
        mysql_query("delete from tabel_surat_masuk where id_surat_masuk=$kddel") or die(mysql_error());
        mysql_query("delete from tabel_pengirim where id_pengirim=$userhapus") or die(mysql_error());
    } else {
        mysql_query("delete from tabel_surat_masuk where id_surat_masuk=$kddel") or die(mysql_error());
    }
}
?>
<script type="text/javascript">document.location='http://<?php echo $host; ?>/si_surat/petugas/suratmasuk/?page=index'</script>