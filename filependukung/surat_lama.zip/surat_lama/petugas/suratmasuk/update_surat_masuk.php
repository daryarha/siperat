<?php
include "../../connection.php";

if (isset($_GET['kdupd'])) {
    $kdupd = $_GET['kdupd'];
} else {
    $kdupd = "";
}

$host = $host;

$query = "Select * from tabel_surat_masuk where id_surat_masuk = $kdupd";
$result = mysql_query($query) or die(mysql_error());
if (mysql_num_rows($result) == 0) {
    echo "<script type='text/javascript'>document.location='http://$host/si_surat/petugas/suratmasuk/?page=index'</script>";
} else {
    $row = mysql_fetch_object($result);
    ?>
    <head>

        <link rel="stylesheet" href="../../validasi/jquery.validationEngine.jquery.css" type="text/css" media="screen" />
        <script src="../../validasi/js/jquery.js" type="text/javascript"></script>
        <script src="../../validasi/jquery.validationEngine-en.js" type="text/javascript"></script>
        <script src="../../validasi/jquery.validationEngine.js" type="text/javascript"></script>
        <link rel="stylesheet" href="../themes/base/jquery.ui.all.css">
    <!--    <script src="../jquery-1.4.4.js"></script>-->
        <script src="../ui/jquery.ui.core.js"></script>
        <script src="../ui/jquery.ui.widget.js"></script>
        <script src="../ui/jquery.ui.datepicker.js"></script>
        <script>
            $(document).ready(function() {
                $("#formID").validationEngine()
            });
        </script>
        <script>
            $(function() {
                //$( "#datepicker" ).datepicker();
                $( "#datepicker" ).datepicker( {dateFormat:"yy-mm-dd",changeMonth: true,
                    changeYear: true} );
                       
            });
        </script>
        <script type="text/javascript">
            var xmlHttp= buatObjekXmlHttp();
            function buatObjekXmlHttp()
            {
                var obj = null;
                if (window.ActiveXObject)
                    obj = new ActiveXObject ("Microsoft.XMLHTTP");
                else
                    if (window.XMLHttpRequest)
                        obj = new XMLHttpRequest();
                //cek isi xmlHttp
                if (obj == null)
                    document.write("Browser tidak mendukung ajax");
                return obj;
            }

            function ambilData(sumber_data, id_elemen)
            {
                if (xmlHttp!= null) //jika object xmlHttp sudah terbentuk
                {
                    var obj = document.getElementById(id_elemen);  //memasukkan nilai id_elemen ke dalam object var
                    xmlHttp.open("GET", sumber_data);//untuk menyiapkan permintaan ke server metodenya ada dua GET dan POST, sumber_data-> URL

                    xmlHttp.onreadystatechange = function () //status server
                    {
                        if (xmlHttp.readyState == 4) //jika 4 berarti permintaan komplit  ... 4 adalah sudah ketentuan
                        {

                            if (xmlHttp.status == 200) // 200 untuk status OK , 404 untuk status not found
                            {
                                obj.innerHTML = xmlHttp.responseText;
                            }
                            else obj.innerHTML = "Error. Status: " + xmlHttp.status;
                        }
                        else //jika  xmlHttp.readyState masih bukan = 4 , jalankan gambar dibawah ... dengan kata lain permintaan belum selesai

                        obj.innerHTML = "<img src='loading.gif' />"; //gambar loading ... bisa didownload di internet banyak ko ... googling aja

                }
                xmlHttp.send(null); //untuk mengirim permintaan ke server
            }
        }
        function prosesData(sumber_data, id_elemen)

        {

            var id_jenis_pengirim = document.getElementById("jenis_pengirim");

            var elemen_id_jenis_pengirim = id_jenis_pengirim[id_jenis_pengirim.selectedIndex];

            var nilai_id_jenis_pengirim = elemen_id_jenis_pengirim.value;


            var url= sumber_data + "?id_jenis_pengirim=" + nilai_id_jenis_pengirim;
                    

            var a = document.getElementById(id_elemen);
            if (nilai_id_jenis_pengirim!=null) {
                a.innerHTML="";
            }
            ambilData(url,id_elemen);
        }
        </script>
    </head>
    <body>
    <center>
        <form action="?page=prosesSuratMasuk" method="POST" id="formID" class="formular">
            <table>
                <tr>
                    <td colspan="5" align="center" cellpadding="3" ><font size="5"><b>Data Surat Masuk</b></font></td>
                </tr>
                <tr>
                    <td>Nomor Surat</td>
                    <td>:</td>
                    <td colspan="3"><input type="text" size="55" placeholder="input nomor surat" value="<?php echo $row->no_surat_masuk; ?>" id="no_surat"  class="validate[required,maxSize[13]] text-input" name="no_surat"></td>
                </tr>
                <tr>
                    <td>Tanggal</td>
                    <td>:</td>
                    <td><input type="text" name ="tanggal"id="datepicker" placeholder="input tanggal" value ="<?php echo $row->tanggal; ?>"class="validate[required]">
                    </td>
                </tr>
                <tr>
                    <td>Jenis Pengirim </td>
                    <td>:</td>
                    <td colspan="3">
                        <select name="jenis_pengirim" id="jenis_pengirim" onchange="prosesData('prosesAjax.php','pengirim')" class="validate[required]">
                            <option value="">Pilih Jenis Pengirim</option>
                            <?php
                            $res = mysql_query("select id_jenis_pengirim from tabel_pengirim where id_pengirim =$row->id_pengirim");
                            $bar = mysql_fetch_array($res);
                            $idjenispengirim = $bar['id_jenis_pengirim'];

                            $query = "select * from tabel_jenis_pengirim";
                            $sql = mysql_query($query) or die(mysql_error());
                            while ($r = mysql_fetch_object($sql)) {
                                if ($r->id_jenis_pengirim == $idjenispengirim) {
                                    echo "<option value='$r->id_jenis_pengirim' selected>$r->nama_jenis_pengirim</option>";
                                } else {
                                    echo "<option value='$r->id_jenis_pengirim'>$r->nama_jenis_pengirim</option>";
                                }
                            }
                            ?>
                        </select>

                    </td>
                </tr>
                <tr>
                    <td>Pengirim</td>
                    <td>:</td>
                    <td colspan="3">
                        <div id="pengirim" >
                            <?php
                            if ($idjenispengirim == 1) {
                                $query = "select * from tabel_pengirim where id_jenis_pengirim = $idjenispengirim";
                                $sql = mysql_query($query) or die(mysql_error());

                                echo "<select name='pengirim' id='cbPengirim' class='validate[required]'>";
//                            sleep(1);
                                echo "<option value=''>Pilih Pengirim</option>";
                                while ($ba = mysql_fetch_assoc($sql)) {
                                    if ($ba[id_pengirim] == $row->id_pengirim) {
                                        echo "<option value=$ba[id_pengirim] selected>$ba[keterangan]</option>";
                                    } else {
                                        echo "<option value=$ba[id_pengirim]>$ba[keterangan]</option>";
                                    }
                                }
                                echo "</select>";
                            } else {
                                $q = mysql_query("select keterangan from tabel_pengirim where id_pengirim=$row->id_pengirim");
                                $w = mysql_fetch_object($q);
                                echo "<input type='text' name='pengirim' value='$w->keterangan' id='txtPengirim' class='validate[required] text-input' placeholder='input nama pengirim'>";
                            }
                            ?>
                        </div>    
                    </td>
                </tr>
                <tr>
                    <td>Jenis Surat</td>
                    <td>:</td>
                    <td colspan="3">
                        <select name="jenis_surat" id="jenis_surat" class="validate[required]">
                            <option value="">Pilih Jenis Surat</option>
                            <?php
                            $p = mysql_query("select id_jenis_surat from tabel_jenis_surat where id_jenis_surat=$row->id_jenis_surat");
                            $rs = mysql_fetch_object($p);

                            $query = "select * from tabel_jenis_surat";
                            $sql = mysql_query($query) or die(mysql_error());
                            while ($rw = mysql_fetch_object($sql)) {
                                if ($rw->id_jenis_surat == $rs->id_jenis_surat) {
                                    echo "<option value='$rw->id_jenis_surat' selected>$rw->keterangan</option>";
                                } else {
                                    echo "<option value='$rw->id_jenis_surat'>$rw->keterangan</option>";
                                }
                            }
                            ?>
                        </select>
                    </td>
                </tr>
                <tr>
                    <td>Perihal</td>
                    <td>:</td>
                    <td colspan="3"><input type="text" id="perihal" name="perihal"size="55" placeholder="input perihal"value="<?php echo $row->perihal; ?>" class="validate[required] text-input"/></td>
                </tr>
                <tr>
                    <td>Lampiran</td>
                    <td>:</td>
                    <td colspan="3"><input type="text" id="lampiran" value="<?php echo $row->lampiran; ?>" placeholder="input lampiran"name="lampiran" size="55"/></td>
                </tr> 
                <tr>
                    <td>Tindakan</td>
                    <td>:</td>
                    <td colspan="3">
                        <input type="radio" name="tindakan"  value="Tidak Dibalas" <?php
                        if ($row->tindakan == "Tidak Dibalas") {
                            echo "checked";
                        }
                            ?>>Tidak Dibalas &nbsp;
                        <input type="radio" name="tindakan" value="Dibalas"<?php
                           if ($row->tindakan == "Dibalas") {
                               echo "checked";
                           }
                            ?>>Dibalas
                    </td>
                </tr>
                <tr>
                    <td>Keterangan</td>
                    <td>:</td>
                    <td colspan="3"><textarea style="width: 339px" id="keterangan"  name="keterangan" placeholder="input keterangan"><?php echo $row->keterangan; ?></textarea></td>
                </tr>
                <tr>
                    <td colspan="5" align="center">
                        <input type="submit" value="Submit"/>
                        <input type="reset" value="Reset"/>
                    </td>
                </tr>
            </table>
            <input type="hidden" name="kdupd" value="<?php echo $kdupd; ?>">
        </form>
        <br>
        <a href="index.php">Lihat Data</a>
    </center>
    </body>
    <?php
}
?>