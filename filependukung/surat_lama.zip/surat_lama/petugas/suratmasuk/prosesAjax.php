<?php

include '../../connection.php';

$idjp = $_GET['id_jenis_pengirim'];
if ($idjp == 1) {
    $query = "select * from tabel_pengirim where id_jenis_pengirim = $idjp";
    $sql = mysql_query($query) or die(mysql_error());

    echo "<select name='pengirim' id='cbPengirim' class='validate[required]'>";
    sleep(1);
    echo "<option value=''>Pilih Pengirim</option>";
    while ($row = mysql_fetch_assoc($sql)) {
        echo "<option value=$row[id_pengirim]>$row[keterangan]</option>";
    }
    echo "</select>";
} else {
    echo "<input type='text' name='pengirim' id='txtPengirim' class='validate[required] text-input' placeholder='input nama pengirim'>";
}
?>
