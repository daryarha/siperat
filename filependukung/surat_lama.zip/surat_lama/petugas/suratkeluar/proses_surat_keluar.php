<?php
include '../../connection.php';

if (isset($_POST['pengirim'])) {
    $pengirim = $_POST['pengirim'];
} else {
    $pengirim = "";
}

if (isset($_POST['nama_pemohon'])) {
    $nama_pemohon = $_POST['nama_pemohon'];
} else {
    $nama_pemohon = "";
}

if (isset($_POST['nim_pemohon'])) {
    $nim_pemohon = $_POST['nim_pemohon'];
} else {
    $nim_pemohon = "";
}

if (isset($_POST['no_hp_pemohon'])) {
    $no_hp_pemohon = $_POST['no_hp_pemohon'];
} else {
    $no_hp_pemohon = "";
}

if (isset($_POST['jenis_surat'])) {
    $jenis_surat = $_POST['jenis_surat'];
} else {
    $jenis_surat = "";
}
if (isset($_POST['jenis_penerima'])) {
    $jenis_penerima = $_POST['jenis_penerima'];
} else {
    $jenis_penerima = "";
}
if (isset($_POST['tanggal'])) {
    $tanggal = $_POST['tanggal'];
} else {
    $tanggal = "";
}
if (isset($_POST['perihal'])) {
    $perihal = $_POST['perihal'];
} else {
    $perihal = "";
}
if (isset($_POST['lampiran'])) {
    $lampiran = $_POST['lampiran'];
} else {
    $lampiran = "";
}
if (isset($_POST['keterangan'])) {
    $keterangan = $_POST['keterangan'];
} else {
    $keterangan = "";
}

if (isset($_POST['status_arsip'])) {
    $status_arsip = $_POST['status_arsip'];
} else {
    $status_arsip = "";
}


if (isset($_POST['kdupd'])) {
    $kdupd = $_POST['kdupd'];
} else {
    $kdupd = "";
}
if (isset($_GET['kddel'])) {
    $kddel = $_GET['kddel'];
} else {
    $kddel = "";
}



if (($kdupd == "") && ($kddel == "")) {

    $qq = mysql_query("select max(id_surat_keluar) as max from tabel_surat_keluar");
    $rr = mysql_fetch_object($qq);
    $idsk = $rr->max + 1;

    if ($idsk < 10) {
        $nos = "00$idsk";
    } else if ($idsk >= 10 && $idsk < 100) {
        $nos = "0$idsk";
    } else if ($idsk >= 100) {
        $nos = $idsk;
    }

    $hh = mysql_query("select kode_pengirim from tabel_pengirim where id_pengirim = $pengirim");
    $ss = mysql_fetch_object($hh);
    $kdpengirim = $ss->kode_pengirim;

    $oo = mysql_query("select kode_jenis_surat from tabel_jenis_surat where id_jenis_surat=$jenis_surat");
    $yy = mysql_fetch_object($oo);
    $kdjnssurat = $yy->kode_jenis_surat;

    $tt = mysql_query("select kode_jenis_penerima from tabel_jenis_penerima where id_jenis_penerima=$jenis_penerima");
    $aa = mysql_fetch_object($tt);
    $kdjnspenerima = $aa->kode_jenis_penerima;

    $bulan = substr($tanggal, 5, 2);
	$bln="";
	
    switch ($bulan) {
        case "01":
            $bln = "I";
            break;
        case "02":
            $bln = "II";
            break;
        case "03":
            $bln = "III";
            break;
        case "04":
            $bln = "IV";
            break;
        case "05":
            $bln = "V";
            break;
        case "06":
            $bln = "VI";
            break;
        case "07":
            $bln = "VII";
            break;
        case "08":
            $bln = "VIII";
            break;
        case "09":
            $bln = "IX";
            break;
        case "10":
            $bln = "X";
            break;
        case "11":
            $bln = "XI";
            break;
        case "12":
            $bln = "XII";
            break;
    }

    $tahun = substr($tanggal, 0, 4);

    $no_surat = "$nos/BEM TIIK-UB/$kdpengirim/$kdjnssurat/$kdjnspenerima/$bln/$tahun";

    $query = "Insert into tabel_surat_keluar(id_surat_keluar,no_surat_keluar,id_jenis_surat,
        id_jenis_penerima,id_pengirim,perihal,keterangan,lampiran,tanggal,nama_pemohon,nim_pemohon,no_hp_pemohon,id_status_arsip)
        values($idsk,'$no_surat',$jenis_surat,$jenis_penerima,$pengirim,'$perihal','$keterangan','$lampiran','$tanggal',
    '$nama_pemohon','$nim_pemohon','$no_hp_pemohon',1)";
    mysql_query($query) or die(mysql_error());
}
if ($kdupd != "") {


    $idsk = $kdupd;

    if ($idsk < 10) {
        $nos = "00$idsk";
    } else if ($idsk >= 10 && $idsk < 100) {
        $nos = "0$idsk";
    } else if ($idsk >= 100) {
        $nos = $idsk;
    }

    $hh = mysql_query("select kode_pengirim from tabel_pengirim where id_pengirim = $pengirim");
    $ss = mysql_fetch_object($hh);
    $kdpengirim = $ss->kode_pengirim;

    $oo = mysql_query("select kode_jenis_surat from tabel_jenis_surat where id_jenis_surat=$jenis_surat");
    $yy = mysql_fetch_object($oo);
    $kdjnssurat = $yy->kode_jenis_surat;

    $tt = mysql_query("select kode_jenis_penerima from tabel_jenis_penerima where id_jenis_penerima=$jenis_penerima");
    $aa = mysql_fetch_object($tt);
    $kdjnspenerima = $aa->kode_jenis_penerima;

    $bulan = substr($tanggal, 5, 2);
	$bln="";
	
    switch ($bulan) {
        case "01":
            $bln = "I";
            break;
        case "02":
            $bln = "II";
            break;
        case "03":
            $bln = "III";
            break;
        case "04":
            $bln = "IV";
            break;
        case "05":
            $bln = "V";
            break;
        case "06":
            $bln = "VI";
            break;
        case "07":
            $bln = "VII";
            break;
        case "08":
            $bln = "VIII";
            break;
        case "09":
            $bln = "IX";
            break;
        case "10":
            $bln = "X";
            break;
        case "11":
            $bln = "XI";
            break;
        case "12":
            $bln = "XII";
            break;
    }

    $tahun = substr($tanggal, 0, 4);

    $no_surat = "$nos/BEM TIIK-UB/$kdpengirim/$kdjnssurat/$kdjnspenerima/$bln/$tahun";

    $query = "Update tabel_surat_keluar set no_surat_keluar='$no_surat',id_jenis_surat=$jenis_surat,id_jenis_penerima=$jenis_penerima
    ,id_pengirim=$pengirim,perihal='$perihal',keterangan='$keterangan',lampiran='$lampiran',tanggal='$tanggal', 
    nama_pemohon='$nama_pemohon',nim_pemohon='$nim_pemohon',no_hp_pemohon='$no_hp_pemohon',
    id_status_arsip=$status_arsip where id_surat_keluar=$kdupd";
    mysql_query($query) or die(mysql_error());
}
if ($kddel != "") {
    $query = "delete from tabel_surat_keluar where id_surat_keluar=$kddel";
    mysql_query($query) or die(mysql_error());
}

?>
<script type="text/javascript">document.location='http://<?php echo $host; ?>/si_surat/petugas/suratkeluar/?page=index'</script>