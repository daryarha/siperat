<?php
include '../../connection.php';

if (isset($_GET['act'])&&isset($_GET['val'])&&isset($_GET['id'])) {
    $action=$_GET['act'];
    $value=$_GET['val'];
    $id=$_GET['id'];
    if($action=='status'){
        $tanggal=date('Y-m-d');
        $sql="SELECT id_pengirim, id_jenis_surat, id_jenis_penerima from tabel_surat_keluar where id_surat_keluar='$id'";
        $query = mysql_query($sql) or die(mysql_error());
        $res = mysql_fetch_row($query);
        
        $pengirim=$res[0];
        $jenis_surat=$res[1];
        $jenis_penerima=$res[2];
        $qq = mysql_query("select count(id_surat) as max from tabel_no_surat_keluar");
        $rr = mysql_fetch_object($qq);
        $idsk = $rr->max + 1;
    
        if ($idsk < 10) {
            $nos = "00$idsk";
        } else if ($idsk >= 10 && $idsk < 100) {
            $nos = "0$idsk";
        } else if ($idsk >= 100) {
            $nos = $idsk;
        }
    
        $hh = mysql_query("select kode_pengirim from tabel_pengirim where id_pengirim = $pengirim");
        $ss = mysql_fetch_object($hh);
        $kdpengirim = $ss->kode_pengirim;
    
        $oo = mysql_query("select kode_jenis_surat from tabel_jenis_surat where id_jenis_surat=$jenis_surat");
        $yy = mysql_fetch_object($oo);
        $kdjnssurat = $yy->kode_jenis_surat;
    
        $tt = mysql_query("select kode_jenis_penerima from tabel_jenis_penerima where id_jenis_penerima=$jenis_penerima");
        $aa = mysql_fetch_object($tt);
        $kdjnspenerima = $aa->kode_jenis_penerima;
    
        $bulan = substr($tanggal, 5, 2);
    	$bln="";
    	
        switch ($bulan) {
            case "01":
                $bln = "I";
                break;
            case "02":
                $bln = "II";
                break;
            case "03":
                $bln = "III";
                break;
            case "04":
                $bln = "IV";
                break;
            case "05":
                $bln = "V";
                break;
            case "06":
                $bln = "VI";
                break;
            case "07":
                $bln = "VII";
                break;
            case "08":
                $bln = "VIII";
                break;
            case "09":
                $bln = "IX";
                break;
            case "10":
                $bln = "X";
                break;
            case "11":
                $bln = "XI";
                break;
            case "12":
                $bln = "XII";
                break;
        }
    
        $tahun = substr($tanggal, 0, 4);
    
        $no_surat = "$nos/BEM TIIK-UB/$kdpengirim/$kdjnssurat/$kdjnspenerima/$bln/$tahun";
        //echo $no_surat;exit;
        $sql="SELECT nomor_surat FROM tabel_no_surat_keluar WHERE id_surat='$id'";
        $query = mysql_query($sql) or die(mysql_error());
        $result = mysql_numrows($query);
        //echo $result;exit;         
        if($result==0&&$value==1){
            $sql1="INSERT INTO tabel_no_surat_keluar(id_surat,nomor_surat) VALUES($id,'$no_surat')";
            $query = mysql_query($sql1) or die(mysql_error());
        }
        $sql2="UPDATE tabel_surat_keluar SET id_status_surat=$value WHERE id_surat_keluar=$id";
        
        $query = mysql_query($sql2) or die(mysql_error());
        if($query)echo 1;
    }
    else if($action=='arsip'){
        $sql2="UPDATE tabel_surat_keluar SET id_status_arsip=$value WHERE id_surat_keluar=$id";
        
        $query = mysql_query($sql2) or die(mysql_error());
        if($query)echo 1;
    }
    else if($action=='nomor'){
        $sql="SELECT nomor_surat FROM tabel_no_surat_keluar WHERE id_surat='$id'";
        $query = mysql_query($sql) or die(mysql_error());
        $jumlah = mysql_numrows($query);
        if($jumlah!=0){
            $res=mysql_fetch_row($query);
            echo $res[0];
        }
        else echo '0';
    }
} else {
    echo '0';
}

?>