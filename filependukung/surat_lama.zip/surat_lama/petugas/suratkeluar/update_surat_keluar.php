<?php
include "../../connection.php";


if (isset($_GET['kdupd'])) {
    $kdupd = $_GET['kdupd'];
} else {
    $kdupd = "";
}
$host = $host;

$query = "select * from tabel_surat_keluar where id_surat_keluar=$kdupd";
$result = mysql_query($query) or die(mysql_error());
if (mysql_num_rows($result) == 0) {
    echo "<script type='text/javascript'>document.location='http://$host/si_surat/petugas/suratkeluar/?page=index'</script>";
} else {
    $row = mysql_fetch_object($result);
    ?>
    <head>

        <link rel="stylesheet" href="../../validasi/jquery.validationEngine.jquery.css" type="text/css" media="screen" />
        <script src="../../validasi/js/jquery.js" type="text/javascript"></script>
        <script src="../../validasi/jquery.validationEngine-en.js" type="text/javascript"></script>
        <script src="../../validasi/jquery.validationEngine.js" type="text/javascript"></script>
        <link rel="stylesheet" href="../themes/base/jquery.ui.all.css">
    <!--    <script src="../jquery-1.4.4.js"></script>-->
        <script src="../ui/jquery.ui.core.js"></script>
        <script src="../ui/jquery.ui.widget.js"></script>
        <script src="../ui/jquery.ui.datepicker.js"></script>
        <script>
            $(document).ready(function() {
                $("#formID").validationEngine()
            });
        </script>
        <script>
            $(function() {
                //$( "#datepicker" ).datepicker();
                $( "#datepicker" ).datepicker( {dateFormat:"yy-mm-dd",changeMonth: true,
                    changeYear: true} );
               
            });
        </script>
    </head>
    <body>
    <center>
        <form action="?page=prosesSuratKeluar" method="POST" id="formID" class="formular">
            <table>
                <tr>
                    <td colspan="5" align="center" cellpadding="3" ><font size="5"><b>Data Surat Keluar</b></font></td>
                </tr>
                <tr>
                    <td>Pengirim</td>
                    <td>:</td>
                    <td colspan="3">
                        <select style="width: 305px;" name="pengirim" id="pengirim" class="validate[required]">
                            <option value="">Pilih Pengirim</option>
                            <?php
                            $que = mysql_query("select * from tabel_pengirim where id_jenis_pengirim=1");
                            while ($r = mysql_fetch_object($que)) {
                                if ($r->id_pengirim == $row->id_pengirim) {
                                    echo "<option value='$r->id_pengirim' selected>$r->keterangan</option>";
                                } else {
                                    echo "<option value='$r->id_pengirim'>$r->keterangan</option>";
                                }
                            }
                            ?>
                        </select>
                    </td>
                </tr>
                <tr>
                    <td>Nama Acara/Kegiatan</td>
                    <td>:</td>
                    <td><input type="text" name ="nama_acara"id="nama_acara" placeholder="input nama acara" class="validate[required]" value="<?php echo $row->nama_acara; ?>">
                    </td>
                </tr>
                <tr>
                    <td>Nama Pemohonon</td>
                    <td>:</td>
                    <td colspan="3"><input type="text" size="45" placeholder="input nama pemohon" name="nama_pemohon" id="nama_pemohon" class="validate[required]" value="<?php echo $row->nama_pemohon ?>"/></td>
                </tr>
                <tr>
                    <td>NIM Pemohonon</td>
                    <td>:</td>
                    <td colspan="3"><input type="text" size="45" placeholder="input nim pemohon" name="nim_pemohon" id="nim_pemohon" class="validate[required]" value="<?php echo $row->nim_pemohon ?>"/></td>
                </tr>
                <tr>
                    <td>No HP Pemohonon</td>
                    <td>:</td>
                    <td colspan="3"><input type="text" size="45" placeholder="input no hp pemohon" name="no_hp_pemohon" id="no_hp_pemohon" class="validate[required]" value="<?php echo $row->no_hp_pemohon ?>"/></td>
                </tr>
                <tr>
                    <td>Jenis Surat</td>
                    <td>:</td>
                    <td colspan="3">
                        <select style="width: 305px;" name="jenis_surat" id="jenis_surat" class="validate[required]">
                            <option value="">Pilih Jenis Surat</option>
                            <?php
                            $que = mysql_query("select * from tabel_jenis_surat");
                            while ($r = mysql_fetch_object($que)) {
                                if ($r->id_jenis_surat == $row->id_jenis_surat) {
                                    echo "<option value='$r->id_jenis_surat' selected>$r->keterangan</option>";
                                } else {
                                    echo "<option value='$r->id_jenis_surat'>$r->keterangan</option>";
                                }
                            }
                            ?>
                        </select>
                    </td>
                </tr>
                <tr>
                    <td>Kategori Penerima</td>
                    <td>:</td>
                    <td colspan="3">
                        <select style="width: 305px;" name="jenis_penerima" id="jenis_penerima" class="validate[required]">
                            <option value="">Pilih Kategori Penerima</option>
                            <?php
                            $que = mysql_query("select * from tabel_jenis_penerima");
                            while ($r = mysql_fetch_object($que)) {
                                if ($r->id_jenis_penerima == $row->id_jenis_penerima) {
                                    echo "<option value='$r->id_jenis_penerima' selected>$r->nama_jenis_penerima</option>";
                                } else {
                                    echo "<option value='$r->id_jenis_penerima'>$r->nama_jenis_penerima</option>";
                                }
                            }
                            ?>
                        </select>
                    </td>
                </tr>
                <tr>
                    <td>Nama Penerima / Instansi Penerima</td>
                    <td>:</td>
                    <td><input type="text" name ="nama_penerima"id="nama_penerima" placeholder="nama penerima" class="validate[required]" value="<?php echo $row->nama_penerima; ?>">
                    </td>
                </tr>
                <tr>
                    <td>Tanggal</td>
                    <td>:</td>
                    <td><input type="text" name ="tanggal"id="datepicker" value="<?php echo $row->tanggal; ?>" placeholder="input tanggal" class="validate[required]">
                    </td>
                </tr>
                <tr>
                    <td>Perihal</td>
                    <td>:</td>
                    <td colspan="3"><input type="text" size="45" name="perihal" placeholder="input perihal" value="<?php echo $row->perihal; ?>" id="perihal" class="validate[required]"/></td>
                </tr>
                <tr>
                    <td>Lampiran</td>
                    <td>:</td>
                    <td colspan="3"><input type="text" size="45" name="lampiran" placeholder="input lampiran" value="<?php echo $row->lampiran; ?>" id="lampiran"/></td>
                </tr>
                <tr>
                    <td>Keterangan</td>
                    <td>:</td>
                    <td colspan="3"><textarea style="width: 305px;" name="keterangan" placeholder="input keterangan" id="keterangan"><?php echo $row->keterangan; ?></textarea></td>
                </tr>
                <tr>
                    <td>Pengarsipan</td>
                    <td>:</td>
                    <td colspan="3">
                        <?php
                        $ars = mysql_query("select * from tabel_status_arsip");
                        while ($r = mysql_fetch_object($ars)) {
                            if ($r->id_status_arsip == $row->id_status_arsip) {
                                $chck = "checked";
                            } else {
                                $chck = "";
                            }
                            echo "<input type='radio' name='status_arsip' value='$r->id_status_arsip' $chck>$r->ket_status_arsip &nbsp;";
                        }
                        ?>
                    </td>
                </tr>
                <tr>
                    <td colspan="5" align="center">
                        <input type="submit" value="Submit"/>
                        <input type="Reset" value="Reset"/>
                    </td>
                </tr>
            </table>
            <input type="hidden" name="kdupd" value="<?php echo $kdupd; ?>">
        </form>
        <a href="index.php">Lihat Data</a>

    </center>
    </body>
<?php } ?> 