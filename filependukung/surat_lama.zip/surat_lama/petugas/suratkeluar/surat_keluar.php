<?php ?>
<head>
    <link rel="stylesheet" href="../../tablesorter/style.css" type="text/css" media="print, projection, screen" />
    <script type="text/javascript" src="../../tablesorter/jquery-latest.js"></script>
    <script type="text/javascript" src="../../tablesorter/jquery.tablesorter.js"></script>
    <script type="text/javascript" src="../../tablesorter/jquery.tablesorter.pager.js"></script>
    <script src="../../jquery-1.10.2.min.js" type="text/javascript"></script>

    <script type="text/javascript">
        $(document).ready(function(){
          $("#but").click(function(){
            $('#tabel tr:nth-child(2) td:nth-child(3)').html('good');
          });
        });
        
        $(function() {
            $("table")
            .tablesorter({widthFixed: true, widgets: ['zebra'],
                headers: {
                    // assign the secound column (we start counting zero)
                    4: {
                        // disable it by setting the property sorter to false
                        sorter: false
                    },
                    11: {
                        // disable it by setting the property sorter to false
                        sorter: false
                    }
                    
                }})
            .tablesorterPager({container: $("#pager"),positionFixed: false });
            
        });
        
        function change_status(row_num,id_surat,obj){
            value=obj.options[obj.selectedIndex].value;
            $("#aa").html('bisa');
            $.ajax({
				type: "GET",
			    url: "http://bemtiik.ub.ac.id/surat/petugas/suratkeluar/ajax.php?act=status&val="+value+"&id="+id_surat,
			    data: "",
			    success: function(msg){
			    	if(msg=='1'){
                        if(value==1){
                            $.ajax({
                				type: "GET",
                			    url: "http://bemtiik.ub.ac.id/surat/petugas/suratkeluar/ajax.php?act=nomor&val="+value+"&id="+id_surat,
                			    data: "",
                			    success: function(msg){
                			    	if(msg!='0'){
                                        $(obj).attr('disabled','true');
                                        $(obj).parent().attr('style','background:green');
                                        //$('#tabel tr:nth-child('+row+') td:nth-child(3)').html(msg);
                                        $(obj).parent().prev().prev().prev().prev().prev().prev().prev().prev().prev().prev().prev().prev().prev().html(msg);
                                        $(obj).parent().next().html('');
                                        $(obj).parent().next().next().html('');
                                        //alert('#tabel tr:nth-child('+row_num+') td:nth-child(3)'+' '+msg);
                			    	}
                			    	else{
                			    		alert("Gagal update status surat");
                			    	}
                			    	
                			    }
                			});
                        }
                        else if(value==2){
                            $(obj).attr('disabled','true');
                            $(obj).parent().attr('style','background:red');
                            $(obj).parent().next().html('');
                            $(obj).parent().next().next().html('');
                        }
			    	}
			    	else{
			    		alert("Gagal update status surat");
			    	}
			    	
			    }
			});
        }
        
        function change_arsip(row_num,id_surat,obj){
            value=obj.options[obj.selectedIndex].value;
            $.ajax({
				type: "GET",
			    url: "http://bemtiik.ub.ac.id/surat/petugas/suratkeluar/ajax.php?act=arsip&val="+value+"&id="+id_surat,
			    data: "",
			    success: function(msg){
			    	if(msg!='0'){
                        if(value==1)$(obj).parent().attr('style','background:yellow');
                        if(value==2)$(obj).parent().attr('style','background:white');
			    	}
			    	else{
			    		alert("Gagal update arsip surat");
			    	}
			    	
			    }
			});
        }
    </script>
    <script type="text/javascript">

        function conf(){
            if(confirm("Anda Yakin ?")){
                return true;

            }else{
                window.close();
                return false;
            }
        }
    </script>
</head>
<body>
<center><h2>Data Surat Keluar</h2>
    <hr>
    <!--<b><a href=?page=inputSuratKeluar>Insert Data</a></b>--></center>
<?php
include '../../connection.php';
$sql = "SELECT a.id_surat_keluar as idSuratKeluar, a.tanggal, 
b.keterangan AS jenisSurat, a.perihal, a.lampiran, a.keterangan, c.nama_jenis_penerima as penerima, 
d.keterangan AS pengirim,a.nama_pemohon,a.nim_pemohon,a.no_hp_pemohon, e.ket_status_arsip, a.nama_penerima, a.nama_acara, a.id_status_surat
FROM tabel_surat_keluar a, tabel_jenis_surat b, tabel_jenis_penerima c, tabel_pengirim d, tabel_status_arsip e
WHERE a.id_jenis_surat = b.id_jenis_surat
AND a.id_jenis_penerima = c.id_jenis_penerima
AND a.id_pengirim = d.id_pengirim
AND a.id_status_arsip = e.id_status_arsip order by a.tanggal desc;";
$query = mysql_query($sql) or die(mysql_error());
$no = 1;
function get_no_surat($id_surat){
    $sql="SELECT nomor_surat FROM tabel_no_surat_keluar WHERE id_surat='$id_surat'";
    $query = mysql_query($sql) or die(mysql_error());
    $result = mysql_fetch_row($query);
    return $result[0];
}
if (mysql_num_rows($query) > 0) {
    ?>
    <table class="tablesorter" id="tabel" cellspacing="1" >
        <thead>
            <tr>
                <th rowspan="2">No</th>
                <th rowspan="2">Tanggal</th>
                <th rowspan="2">No Surat</th>
                <th rowspan="2">Pengirim</th>
                <th rowspan="2">Nama Acara</th>
                <th colspan="3"><center>Pemohon</center></th>
    <th rowspan="2">Jenis Surat</th>
    <th rowspan="2">Penerima</th>
    <th rowspan="2">Nama Penerima</th>
    <th rowspan="2">Perihal</th>                
    <th rowspan="2">Lampiran</th>              
    <th rowspan="2">Keterangan</th>
    <th rowspan="2">Arsip</th>
    <th rowspan="2">Status Surat</th>
    <th rowspan="2" colspan="2">Aksi</th>
    </tr>
    <tr>
        <th>Nama</th>
        <th>NIM</th>
        <th>No. HP</th>
    </tr>
    </thead>
    <tbody>
        <?php
        while ($row = mysql_fetch_object($query)) {
            ?>
            <tr>
                <td><?php echo $no++ ?></td>
                <td><?php echo $row->tanggal; ?></td>
                <td><?php echo get_no_surat($row->idSuratKeluar); ?></td>
                <td><?php echo $row->pengirim; ?></td>
                <td><?php echo $row->nama_acara; ?></td>
                <td><?php echo $row->nama_pemohon; ?></td>
                <td><?php echo $row->nim_pemohon; ?></td>
                <td><?php echo $row->no_hp_pemohon; ?></td>
                <td><?php echo $row->jenisSurat; ?></td>
                <td><?php echo $row->penerima; ?></td>
                <td><?php echo $row->nama_penerima; ?></td>
                <td><?php echo $row->perihal; ?></td>
                <td><?php echo $row->lampiran; ?></td>
                <td><?php echo $row->keterangan; ?></td>
                <td <?php $stat_arsip=$row->ket_status_arsip; if($stat_arsip=='Belum')echo 'style="background:yellow"'?>>
                    <select onchange="change_arsip(<?php echo $no.','.$row->idSuratKeluar; ?>,this)" >
                        <option value="1" <?php if($stat_arsip=='Belum')echo 'selected';?>> Belum</option>
                        <option value="2" <?php if($stat_arsip=='Sudah')echo 'selected';?>> Sudah</option>
                    </select>
                </td>
                <td <?php $stat=$row->id_status_surat;
                    if($stat==0)echo 'style="background:orange"';
                    else if($stat==1)echo 'style="background:green"';
                    else if($stat==2)echo 'style="background:red"';
                    ?>>
                    <select <?php if($stat==1||$stat==2)echo 'disabled';?> onchange="change_status(<?php echo $no.','.$row->idSuratKeluar; ?>,this)" >
                        <option value="0" <?php if($stat==0)echo 'selected';?>> Diproses</option>
                        <option value="1" <?php if($stat==1)echo 'selected';?>> Disetujui</option>
                        <option value="2" <?php if($stat==2)echo 'selected';?>> Ditolak</option>
                    </select>
                    <!--<input type="checkbox" onclick="change_status(<?php $param=$no.','.$row->idSuratKeluar; if($stat==1)$param.=',0';else $param.=',1'; echo $param; ?>)" <?php $stat=$row->id_status_surat;
                    if($stat==1)echo 'checked';
                    ?> />-->
                </td>
                <td><?php if($stat==0){?><a href='?page=updateSuratKeluar&kdupd=<?= $row->idSuratKeluar ?>'><img src="../../img/edit.png" width="25" height="25"></a><?php } ?></td>
                <td><?php if($stat==0){?><a href='?page=prosesSuratKeluar&kddel=<?= $row->idSuratKeluar ?>' onclick="return conf();"><img src="../../img/delete.png" width="25" height="25"></a><?php } ?></td>
                
            </tr>
            <?php
        }
        ?>
    </tbody>

    </table>
    <div id="pager" class="pager" align="">
        <form>
            <img src="../../tablesorter/img/first.gif" class="first"/>
            <img src="../../tablesorter/img/prev.gif" class="prev"/>
            <input type="text" class="pagedisplay"/>
            <img src="../../tablesorter/img/next.gif" class="next"/>
            <img src="../../tablesorter/img/last.gif" class="last"/>
            <select class="pagesize">
                <option value="10" selected="selected">10</option>

                <option value="20">20</option>
                <option value="30">30</option>
                <option  value="40">40</option>
                <option  value="50">50</option>
                <option  value="100">100</option>
            </select>
        </form>
    </div>
    <center><a href='../../logout.php'>Logout</a></center>
    </body>
    <?php
} else {
    echo "<br>";
    echo "<center>";
    echo "Data tidak ada<br>";
    echo "<a href='../../logout.php'>Logout</a>";
    echo "</center>";
}
?>