<?php

session_start();
if (!isset($_SESSION['username'])) {
    ?>
    <script type="text/javascript">document.location='../../index.php'</script>
    <?php

}
if ($_SESSION['id_priv'] != 2) {
    echo "<script type='text/javascript'>history.go(-1);</script>";
}
?>
<?php

if (isset($_GET['page'])) {
    $page = $_GET['page'];
    if ($page == "index") {
        include 'surat_keluar.php';
    } else if ($page == "inputSuratKeluar") {
        include 'form_surat_keluar.php';
    } else if ($page == "prosesSuratKeluar") {
        include 'proses_surat_keluar.php';
    } else if ($page == "updateSuratKeluar") {
        include 'update_surat_keluar.php';
    } else {
        echo "<script>
            
            document.location='?page=index';
        </script>";
    }
} else {
    echo "<script>
            
            document.location='?page=index';
        </script>";
}
?>

