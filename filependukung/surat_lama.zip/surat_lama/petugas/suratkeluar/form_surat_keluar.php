<?php
include "../../connection.php";
?>
<head>

    <link rel="stylesheet" href="../../validasi/jquery.validationEngine.jquery.css" type="text/css" media="screen" />
    <script src="../../validasi/js/jquery.js" type="text/javascript"></script>
    <script src="../../validasi/jquery.validationEngine-en.js" type="text/javascript"></script>
    <script src="../../validasi/jquery.validationEngine.js" type="text/javascript"></script>
    <link rel="stylesheet" href="../themes/base/jquery.ui.all.css">
<!--    <script src="../jquery-1.4.4.js"></script>-->
    <script src="../ui/jquery.ui.core.js"></script>
    <script src="../ui/jquery.ui.widget.js"></script>
    <script src="../ui/jquery.ui.datepicker.js"></script>
    <script>
        $(document).ready(function() {
            $("#formID").validationEngine()
        });
    </script>
    <script>
        $(function() {
            //$( "#datepicker" ).datepicker();
            $( "#datepicker" ).datepicker( {dateFormat:"yy-mm-dd",changeMonth: true,
                changeYear: true} );
           
        });
    </script>
</head>
<body>
<center>
    <?php if(isset($_GET['status']))if($_GET['status']==1)echo '<h4 style="background:orange">Permohonan telah dikirim</h4>';?>a
    <form action="?page=prosesSuratKeluar" method="POST" id="formID" class="formular">
        <table>
            <tr>
                <td colspan="5" align="center" cellpadding="3" ><font size="5"><b>Data Surat Keluar</b></font></td>
            </tr>
            <tr>
                <td>Pengirim</td>
                <td>:</td>
                <td colspan="3">
                    <select style="width: 305px;" name="pengirim" id="pengirim" class="validate[required]">
                        <option value="">Pilih Pengirim</option>
                        <?php
                        $que = mysql_query("select * from tabel_pengirim where id_jenis_pengirim=1");
                        while ($row = mysql_fetch_object($que)) {
                            echo "<option value='$row->id_pengirim'>$row->keterangan</option>";
                        }
                        ?>
                    </select>
                </td>
            </tr>
            <tr>
                <td>Nama Acara/Kegiatan</td>
                <td>:</td>
                <td><input type="text" name ="nama_acara"id="nama_acara" placeholder="input nama acara" class="validate[required]">
                </td>
            </tr>
            <tr>
                <td>Nama Pemohonon</td>
                <td>:</td>
                <td colspan="3"><input type="text" size="45" placeholder="input nama pemohon" name="nama_pemohon" id="nama_pemohon" class="validate[required]"/></td>
            </tr>
            <tr>
                <td>NIM Pemohonon</td>
                <td>:</td>
                <td colspan="3"><input type="text" size="45" placeholder="input nim pemohon" name="nim_pemohon" id="nim_pemohon" class="validate[required]"/></td>
            </tr>
            <tr>
                <td>No HP Pemohonon</td>
                <td>:</td>
                <td colspan="3"><input type="text" size="45" placeholder="input no hp pemohon" name="no_hp_pemohon" id="no_hp_pemohon" class="validate[required]"/></td>
            </tr>
            <tr>
                <td>Jenis Surat</td>
                <td>:</td>
                <td colspan="3">
                    <select style="width: 305px;" name="jenis_surat" id="jenis_surat" class="validate[required]">
                        <option value="">Pilih Jenis Surat</option>
                        <?php
                        $que = mysql_query("select * from tabel_jenis_surat");
                        while ($row = mysql_fetch_object($que)) {
                            echo "<option value='$row->id_jenis_surat'>$row->keterangan</option>";
                        }
                        ?>
                    </select>
                </td>
            </tr>
            <tr>
                <td>Kategori Penerima</td>
                <td>:</td>
                <td colspan="3">
                    <select style="width: 305px;" name="jenis_penerima" id="jenis_penerima" class="validate[required]">
                        <option value="">Pilih Kategori Penerima</option>
                        <?php
                        $que = mysql_query("select * from tabel_jenis_penerima");
                        while ($row = mysql_fetch_object($que)) {
                            echo "<option value='$row->id_jenis_penerima'>$row->nama_jenis_penerima</option>";
                        }
                        ?>
                    </select>
                </td>
            </tr>
            <tr>
                <td>Nama Penerima / Instansi Penerima</td>
                <td>:</td>
                <td><input type="text" name ="nama_penerima"id="nama_penerima" placeholder="nama penerima" class="validate[required]">
                </td>
            </tr>
            <tr>
                <td>Tanggal</td>
                <td>:</td>
                <td><input type="text" name ="tanggal"id="datepicker" placeholder="input tanggal" class="validate[required]">
                </td>
            </tr>
            <tr>
                <td>Perihal</td>
                <td>:</td>
                <td colspan="3"><input type="text" size="45" placeholder="input perihal" name="perihal" id="perihal" class="validate[required]"/></td>
            </tr>
            <tr>
                <td>Lampiran</td>
                <td>:</td>
                <td colspan="3"><input type="text" size="45" placeholder="input lampiran" name="lampiran" id="lampiran"/></td>
            </tr>
            <tr>
                <td>Keterangan</td>
                <td>:</td>
                <td colspan="3"><textarea style="width: 305px;" name="keterangan" id="keterangan" placeholder="input keterangan"></textarea></td>
            </tr>
            <tr>
                <td colspan="5" align="center">
                    <input type="submit" value="Submit"/>
                    <input type="Reset" value="Reset"/>
                </td>
            </tr>
        </table>
    </form>
    <a href="index.php">Lihat Data</a>
</center>
</body>