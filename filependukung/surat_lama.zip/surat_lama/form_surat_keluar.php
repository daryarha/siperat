<?php
session_start();
if(empty($_SESSION['nama'])||empty($_SESSION['nim'])&&empty($_SESSION['hp'])){
    header('Location:index.php?page=index');
}
include "connection.php";
?>
<head>

    <link rel="stylesheet" href="validasi/jquery.validationEngine.jquery.css" type="text/css" media="screen" />
    <script src="validasi/js/jquery.js" type="text/javascript"></script>
    <script src="validasi/jquery.validationEngine-en.js" type="text/javascript"></script>
    <script src="validasi/jquery.validationEngine.js" type="text/javascript"></script>
    <link rel="stylesheet" href="petugas/themes/base/jquery.ui.all.css">
<!--    <script src="../jquery-1.4.4.js"></script>-->
    <script src="petugas/ui/jquery.ui.core.js"></script>
    <script src="petugas/ui/jquery.ui.widget.js"></script>
    <script src="petugas/ui/jquery.ui.datepicker.js"></script>
    <script>
        $(document).ready(function() {
            $("#formID").validationEngine()
        });
    </script>
    <script>
        $(function() {
            //$( "#datepicker" ).datepicker();
            $( "#datepicker" ).datepicker( {dateFormat:"yy-mm-dd",changeMonth: true,
                changeYear: true} );
           
        });
    </script>
</head>
<body>
<center>
    <?php if(isset($_GET['status']))if($_GET['status']==1)echo 'Permohonan telah dikirim';?><h4></h4>
    <img src="img/contoh.png" style="float: left;" />
    <form action="?page=prosesSuratKeluar" method="POST" id="formID" class="formular">
        <table>
            <tr>
                <td colspan="5" align="center" cellpadding="3" ><font size="5"><b>Data Surat Keluar</b></font></td>
            </tr>
            <tr>
                <td>Pengirim</td>
                <td>:</td>
                <td colspan="3">
                    <select style="width: 305px;" name="pengirim" id="pengirim" class="validate[required]">
                        <option value="">Pilih Pengirim</option>
                        <?php
                        $que = mysqli_query($con,"select * from tabel_pengirim where id_jenis_pengirim=1");
                        while ($row = mysqli_fetch_object($que)) {
                            echo "<option value='$row->id_pengirim'>$row->keterangan</option>";
                        }
                        ?>
                    </select>
                </td>
            </tr>
            <tr>
                <td>Nama Acara/Kegiatan</td>
                <td>:</td>
                <td><input type="text" name ="nama_acara"id="nama_acara" placeholder="input nama acara" class="validate[required]">
                </td>
            </tr>
            <tr>
                <td>Nama Pemohonon</td>
                <td>:</td>
                <td colspan="3"><input type="text" size="45" placeholder="input nama pemohon" name="nama_pemohon" id="nama_pemohon" class="validate[required]" value="<?php echo $_SESSION['nama'];?>" readonly="readonly"/></td>
            </tr>
            <tr>
                <td>NIM Pemohon</td>
                <td>:</td>
                <td colspan="3"><input type="text" size="45" placeholder="input nim pemohon" name="nim_pemohon" id="nim_pemohon" value="<?php echo $_SESSION['nim'];?>" readonly="readonly" class="validate[required]"/></td>
            </tr>
            <tr>
                <td>No HP Pemohon</td>
                <td>:</td>
                <td colspan="3"><input type="text" size="45" placeholder="input no hp pemohon" name="no_hp_pemohon" id="no_hp_pemohon" value="<?php echo $_SESSION['hp'];?>" readonly="readonly" class="validate[required]"/></td>
            </tr>
            <tr>
                <td>Jenis Surat</td>
                <td>:</td>
                <td colspan="3">
                    <select style="width: 305px;" name="jenis_surat" id="jenis_surat" class="validate[required]">
                        <option value="">Pilih Jenis Surat</option>
                        <?php
                        $que = mysqli_query($con,"select * from tabel_jenis_surat");
                        while ($row = mysqli_fetch_object($que)) {
                            echo "<option value='$row->id_jenis_surat'>$row->keterangan</option>";
                        }
                        ?>
                    </select>
                </td>
            </tr>
            <tr>
                <td>Kategori Penerima</td>
                <td>:</td>
                <td colspan="3">
                    <select style="width: 305px;" name="jenis_penerima" id="jenis_penerima" class="validate[required]">
                        <option value="">Pilih Kategori Penerima</option>
                        <?php
                        $que = mysqli_query($con,"select * from tabel_jenis_penerima");
                        while ($row = mysqli_fetch_object($que)) {
                            echo "<option value='$row->id_jenis_penerima'>$row->nama_jenis_penerima</option>";
                        }
                        ?>
                    </select>
                </td>
            </tr>
            <tr>
                <td>Nama Penerima / Instansi Penerima</td>
                <td>:</td>
                <td><input type="text" name ="nama_penerima"id="nama_penerima" placeholder="nama penerima" class="validate[required]">
                </td>
            </tr>
            <!--<tr>
                <td>Tanggal</td>
                <td>:</td>
                <td><input type="text" name ="tanggal"id="datepicker" placeholder="input tanggal" class="validate[required]">
                </td>
            </tr>-->
            <tr>
                <td>Perihal</td>
                <td>:</td>
                <td colspan="3"><input type="text" size="45" placeholder="input perihal" name="perihal" id="perihal" class="validate[required]"/></td>
            </tr>
            <tr>
                <td>Lampiran</td>
                <td>:</td>
                <td colspan="3"><input type="text" size="45" placeholder="input lampiran" name="lampiran" id="lampiran"/></td>
            </tr>
            <tr>
                <td>Keterangan</td>
                <td>:</td>
                <td colspan="3"><textarea style="width: 305px;" name="keterangan" id="keterangan" placeholder="Berisi keterangan surat, misalnya permohonan peminjaman ruang dan inventaris PTIIK"></textarea></td>
            </tr>
            <tr>
                <td colspan="5" align="center">
                    <input type="submit" value="Submit"/>
                    <input type="Reset" value="Reset"/>
                </td>
            </tr>
        </table>
    </form>
    <a href="lihat_surat_keluar.php?nim=<?php echo $_SESSION['nim'];?>">Lihat Status Surat</a> | <a href="pemohon_keluar.php">KELUAR</a>
</center>
</body>