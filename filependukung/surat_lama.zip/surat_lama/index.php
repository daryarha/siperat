<?php

if (isset($_GET['page'])) {
    $page = $_GET['page'];
    if ($page == "index") {
        include 'pemohon.php';
    } else if ($page == "permohonan") {
        include 'form_surat_keluar.php';
    } else if ($page == "prosesSuratKeluar") {
        include 'proses_surat_keluar.php';
    } else {
        echo "<script>
            
            document.location='?page=index';
        </script>";
    }
} else {
    echo "<script>
            
            document.location='?page=index';
        </script>";
}
?>