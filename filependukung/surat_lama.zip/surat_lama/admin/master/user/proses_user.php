<?php
include '../../../connection.php';

if (isset($_POST['username'])) {
    $username = $_POST['username'];
} else {
    $username = "";
}
if (isset($_POST['password'])) {
    $password = $_POST['password'];
} else {
    $password = "";
}

if (isset($_POST['kdupd'])) {
    $kdupd = $_POST['kdupd'];
} else {
    $kdupd = "";
}
if (isset($_GET['kddel'])) {
    $kddel = $_GET['kddel'];
} else {
    $kddel = "";
}

$que = mysqli_query($con, "select max(id_user) as max from tabel_user") or die(mysqli_error($con));
$res = mysqli_fetch_object($que);
$iduser = $res->max + 1;
if ($kdupd == "" && $kddel == "") {
    $query = "insert into tabel_user(id_user,username,password,id_priv) values($iduser,'$username','$password',2)";
    mysqli_query($con,$query) or die(mysqli_error($con));
}

if ($kdupd != "") {
    $query = "update tabel_user set username = '$username', password='$password' where id_user=$kdupd";
    mysqli_query($con,$query) or die(mysqli_error($con));
}

if ($kddel != "") {
    $query = "delete from tabel_user where id_user=$kddel";
    mysqli_query($con,$query) or die(mysqli_error($con));
}
?>
<script type="text/javascript">document.location='http://<?php echo $host; ?>/si_surat/admin/master/user/index.php'</script>
