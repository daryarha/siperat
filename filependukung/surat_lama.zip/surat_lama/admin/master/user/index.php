<?php

session_start();
if (!isset($_SESSION['username'])) {
    ?>
    <script type="text/javascript">document.location='../index.php'</script>
    <?php

}
if ($_SESSION['id_priv'] != 1) {
    echo "<script type='text/javascript'>document.location='../index.php'</script>";
}
?>

<?php

if (isset($_GET['page'])) {
    $page = $_GET['page'];
    if ($page == "index") {
        include 'user.php';
    } else if ($page == "inputUser") {
        include 'form_user.php';
    } else if ($page == "updateUser") {
        include 'update_user.php';
    } else if ($page == "prosesUser") {
        include 'proses_user.php';
    } else {
        echo "<script>document.location='?page=index';</script>";
    }
} else {
    echo "<script>document.location='?page=index';</script>";
}
?>