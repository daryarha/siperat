<?php

session_start();
if (!isset($_SESSION['username'])) {
    ?>
    <script type="text/javascript">document.location='../index.php'</script>
    <?php

}
if ($_SESSION['id_priv'] != 1) {
    echo "<script type='text/javascript'>document.location='../index.php'</script>";
}
?>
<?php

if (isset($_GET['page'])) {
    $page = $_GET['page'];
    if ($page == "index") {
        include 'pengirim.php';
    } else if ($page == "inputPengirim") {
        include 'form_pengirim.php';
    } else if ($page == "updatePengirim") {
        include 'update_pengirim.php';
    } else if ($page == "prosesPengirim") {
        include 'proses_pengirim.php';
    } else {
        echo "<script>document.location='?page=index';</script>";
    }
} else {
    echo "<script>document.location='?page=index';</script>";
}
?>