<?php
?>
<head>
    <link rel="stylesheet" href="../../../tablesorter/style.css" type="text/css" media="print, projection, screen" />
    <script type="text/javascript" src="../../../tablesorter/jquery-latest.js"></script>
    <script type="text/javascript" src="../../../tablesorter/jquery.tablesorter.js"></script>
    <script type="text/javascript" src="../../../tablesorter/jquery.tablesorter.pager.js"></script>

    <script type="text/javascript">
        $(function() {
            $("table")
            .tablesorter({widthFixed: true, widgets: ['zebra'],
                headers: {
                    // assign the secound column (we start counting zero)
                    5: {
                        // disable it by setting the property sorter to false
                        sorter: false
                    }
                }})
            .tablesorterPager({container: $("#pager"),positionFixed: false });
        });
    </script>
    <script type="text/javascript">

        function conf(){
            if(confirm("Anda Yakin ?")){
                return true;

            }else{
                window.close();
                return false;
            }
        }
    </script>
</head>
<body>
<center><h2>Data Pengirim</h2>
    <hr>
    <b><a href=?page=inputPengirim>Insert Data</a></b></center>
<?php
include '../../../connection.php';
$sql = "SELECT a.`id_pengirim` , a.`kode_pengirim` , a.`keterangan` , b.nama_jenis_pengirim
FROM  `tabel_pengirim` a, tabel_jenis_pengirim b
WHERE a.id_jenis_pengirim = b.id_jenis_pengirim";
$query = mysqli_query($con,$sql) or die(mysqli_error($con));
$no = 1;
if (mysqli_num_rows($query) > 0) {
    ?>
    <table class="tablesorter" cellspacing="1">
        <thead>
            <tr>
                <th>No</th>
                <th>ID</th>
                <th>Kode</th>
                <th>Nama</th>
                <th>Jenis Pengirim</th>
                <th colspan="2">Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php
            while ($row = mysqli_fetch_object($query)) {
                ?>
                <tr>
                    <td><?php echo $no++ ?></td>
                    <td><?php echo $row->id_pengirim; ?></td>
                    <td><?php echo $row->kode_pengirim; ?></td>
                    <td><?php echo $row->keterangan; ?></td>
                    <td><?php echo $row->nama_jenis_pengirim; ?></td>
                    <td><a href='?page=updatePengirim&kdupd=<?= $row->id_pengirim ?>'><img src="../../../img/edit.png" width="25" height="25"></a></td>
                    <td><a href='?page=prosesPengirim&kddel=<?= $row->id_pengirim ?>' onclick="return conf();"><img src="../../../img/delete.png" width="25" height="25"></a></td>
                </tr>
                <?php
            }
            ?>
        </tbody>

    </table>
    <div id="pager" class="pager" align="">
        <form>
            <img src="../../../tablesorter/img/first.gif" class="first"/>
            <img src="../../../tablesorter/img/prev.gif" class="prev"/>
            <input type="text" class="pagedisplay"/>
            <img src="../../../tablesorter/img/next.gif" class="next"/>
            <img src="../../../tablesorter/img/last.gif" class="last"/>
            <select class="pagesize">
                <option value="10" selected="selected">10</option>

                <option value="20">20</option>
                <option value="30">30</option>
                <option  value="40">40</option>
                <option  value="50">50</option>
                <option  value="100">100</option>
            </select>
        </form>
    </div>
    <center><a href='../../index.php'>kembali</a></center>
    </body>
    <?php
} else {
    echo "<br>";
    echo "<center>";
    echo "Data tidak ada<br>";
    echo "<a href='../../index.php'>kembali</a>";
    echo "</center>";
}
?>