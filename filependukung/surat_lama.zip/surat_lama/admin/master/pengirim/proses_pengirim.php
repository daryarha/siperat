<?php
include '../../../connection.php';

if (isset($_POST['kode_pengirim'])) {
    $kode_pengirim = $_POST['kode_pengirim'];
} else {
    $kode_pengirim = "";
}
if (isset($_POST['nama_pengirim'])) {
    $nama_pengirim = $_POST['nama_pengirim'];
} else {
    $nama_pengirim = "";
}
if (isset($_POST['jenis_pengirim'])) {
    $jenis_pengirim = $_POST['jenis_pengirim'];
} else {
    $jenis_pengirim = "";
}
if (isset($_POST['kdupd'])) {
    $kdupd = $_POST['kdupd'];
} else {
    $kdupd = "";
}
if (isset($_GET['kddel'])) {
    $kddel = $_GET['kddel'];
} else {
    $kddel = "";
}

$que = mysqli_query($con,"select max(id_pengirim) as max from tabel_pengirim") or die(mysqli_error($con));
$res = mysqli_fetch_object($que);
$idpengirim = $res->max + 1;
if ($kdupd == "" && $kddel == "") {
    $query = "insert into tabel_pengirim(id_pengirim,kode_pengirim,keterangan,id_jenis_pengirim) values($idpengirim,'$kode_pengirim','$nama_pengirim',$jenis_pengirim)";
    mysqli_query($con,$query) or die(mysqli_error($con));
}

if ($kdupd != "") {
    $query = "update tabel_pengirim set kode_pengirim = '$kode_pengirim', keterangan='$nama_pengirim',id_jenis_pengirim=$jenis_pengirim where id_pengirim=$kdupd";
    mysqli_query($con,$query) or die(mysqli_error($con));
}

if ($kddel != "") {
    $query = "delete from tabel_pengirim where id_pengirim=$kddel";
    mysqli_query($con,$query) or die(mysqli_error($con));
}
?>
<script type="text/javascript">document.location='http://<?php echo $host; ?>/si_surat/admin/master/pengirim/index.php'</script>
