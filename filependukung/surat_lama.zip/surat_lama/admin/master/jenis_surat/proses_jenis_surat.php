<?php

include '../../../connection.php';

if (isset($_POST['kode_jenis_surat'])) {
    $kode_js = $_POST['kode_jenis_surat'];
} else {
    $kode_js = "";
}
if (isset($_POST['keterangan'])) {
    $keterangan = $_POST['keterangan'];
} else {
    $keterangan = "";
}

if (isset($_POST['kdupd'])) {
    $kdupd = $_POST['kdupd'];
} else {
    $kdupd = "";
}
if (isset($_GET['kddel'])) {
    $kddel = $_GET['kddel'];
} else {
    $kddel = "";
}

$que = mysqli_query($con,"select max(id_jenis_surat) as max from tabel_jenis_surat") or die(mysqli_error($con));
$res = mysqli_fetch_object($que);
$idjs = $res->max + 1;
if ($kdupd == "" && $kddel == "") {
    $query = "insert into tabel_jenis_surat(id_jenis_surat,kode_jenis_surat,keterangan) values($idjs,'$kode_js','$keterangan')";
    mysqli_query($con,$query) or die(mysqli_error($con));
}

if ($kdupd != "") {
    $query = "update tabel_jenis_surat set kode_jenis_surat = '$kode_js', keterangan='$keterangan' where id_jenis_surat=$kdupd";
    mysqli_query($con,$query) or die(mysqli_error($con));
}

if ($kddel != "") {
    $query = "delete from tabel_jenis_surat where id_jenis_surat=$kddel";
    mysqli_query($con,$query) or die(mysqli_error($con));
}
?>
<script type="text/javascript">document.location='http://<?php echo $host; ?>/si_surat/admin/master/jenis_surat/index.php'</script>
