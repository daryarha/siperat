<?php

session_start();
if (!isset($_SESSION['username'])) {
    ?>
    <script type="text/javascript">document.location='../index.php'</script>
    <?php

}
if ($_SESSION['id_priv'] != 1) {
    echo "<script type='text/javascript'>document.location='../index.php'</script>";
}
?>
<?php

if (isset($_GET['page'])) {
    $page = $_GET['page'];
    if ($page == "index") {
        include 'jenis_surat.php';
    } else if ($page == "inputJenisSurat") {
        include 'form_jenis_surat.php';
    } else if ($page == "updateJenisSurat") {
        include 'update_jenis_surat.php';
    } else if ($page == "prosesJenisSurat") {
        include 'proses_jenis_surat.php';
    } else {
        echo "<script>document.location='?page=index';</script>";
    }
} else {
    echo "<script>document.location='?page=index';</script>";
}
?>