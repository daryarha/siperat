<?php
?>
<head>
    <link rel="stylesheet" href="../../../tablesorter/style.css" type="text/css" media="print, projection, screen" />
    <script type="text/javascript" src="../../../tablesorter/jquery-latest.js"></script>
    <script type="text/javascript" src="../../../tablesorter/jquery.tablesorter.js"></script>
    <script type="text/javascript" src="../../../tablesorter/jquery.tablesorter.pager.js"></script>

    <script type="text/javascript">
        $(function() {
            $("table")
            .tablesorter({widthFixed: true, widgets: ['zebra'],
                headers: {
                    // assign the secound column (we start counting zero)
                    4: {
                        // disable it by setting the property sorter to false
                        sorter: false
                    }
                }})
            .tablesorterPager({container: $("#pager"),positionFixed: false });
        });
    </script>
    <script type="text/javascript">

        function conf(){
            if(confirm("Anda Yakin ?")){
                return true;

            }else{
                window.close();
                return false;
            }
        }
    </script>
</head>
<body>
<center><h2>Data Jenis Surat</h2>
    <hr>
    <b><a href=?page=inputJenisSurat>Insert Data</a></b></center>
<?php
include '../../../connection.php';
$sql = "SELECT * FROM  `tabel_jenis_surat` ";
$query = mysqli_query($con,$sql) or die(mysqli_error($con));
$no = 1;
if (mysqli_num_rows($query) > 0) {
    ?>
    <table class="tablesorter" cellspacing="1">
        <thead>
            <tr>
                <th>No</th>
                <th>ID</th>
                <th>Kode Jenis Surat</th>
                <th>Keterangan</th>
                <th colspan="2">Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php
            while ($row = mysqli_fetch_object($query)) {
                ?>
                <tr>
                    <td><?php echo $no++ ?></td>
                    <td><?php echo $row->id_jenis_surat; ?></td>
                    <td><?php echo $row->kode_jenis_surat; ?></td>
                    <td><?php echo $row->keterangan; ?></td>
                    <td><a href='?page=updateJenisSurat&kdupd=<?= $row->id_jenis_surat ?>'><img src="../../../img/edit.png" width="25" height="25"></a></a></td>
                    <td><a href='?page=prosesJenisSurat&kddel=<?= $row->id_jenis_surat ?>' onclick="return conf();"><img src="../../../img/delete.png" width="25" height="25"></a></td>
                </tr>
                <?php
            }
            ?>
        </tbody>

    </table>
    <div id="pager" class="pager" align="">
        <form>
            <img src="../../../tablesorter/img/first.gif" class="first"/>
            <img src="../../../tablesorter/img/prev.gif" class="prev"/>
            <input type="text" class="pagedisplay"/>
            <img src="../../../tablesorter/img/next.gif" class="next"/>
            <img src="../../../tablesorter/img/last.gif" class="last"/>
            <select class="pagesize">
                <option value="10" selected="selected">10</option>

                <option value="20">20</option>
                <option value="30">30</option>
                <option  value="40">40</option>
                <option  value="50">50</option>
                <option  value="100">100</option>
            </select>
        </form>
    </div>
    <center><a href='../../index.php'>kembali</a></center>
    </body>
    <?php
} else {
    echo "<br>";
    echo "<center>";
    echo "Data tidak ada<br>";
    echo "<a href='../../index.php'>kembali</a>";
    echo "</center>";
}
?>