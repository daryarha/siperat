<?php
include "../../../connection.php";

if (isset($_GET['kdupd'])) {
    $kdupd = $_GET['kdupd'];
} else {
    $kdupd = "";
}

$sql = "SELECT * FROM  `tabel_jenis_surat` where id_jenis_surat=$kdupd";
$query = mysqli_query($con,$sql) or die(mysqli_error($con));
$row = mysqli_fetch_object($query);
?>
<head>

    <link rel="stylesheet" href="../../../validasi/jquery.validationEngine.jquery.css" type="text/css" media="screen" />
    <script src="../../../validasi/js/jquery.js" type="text/javascript"></script>
    <script src="../../../validasi/jquery.validationEngine-en.js" type="text/javascript"></script>
    <script src="../../../validasi/jquery.validationEngine.js" type="text/javascript"></script>
    <link rel="stylesheet" href="../themes/base/jquery.ui.all.css">
    <script>
        $(document).ready(function() {
            $("#formID").validationEngine()
        });
    </script>
</head>
<body>
<center>
    <form action="?page=prosesJenisSurat" method="POST" id="formID" class="formular">
        <table>
            <tr>
                <td colspan="5" align="center" cellpadding="3" ><font size="5"><b>Data Jenis Surat</b></font></td>
            </tr>
            <tr>
                <td>Kode Jenis Surat</td>
                <td>:</td>
                <td colspan="3"><input type="text" size="5" value="<?php echo $row->kode_jenis_surat; ?>" placeholder="input kode jenis surat" id="kode_jenis_surat"  class="validate[required] text-input" name="kode_jenis_surat"></td>
            </tr>
            <tr>
                <td>Nama Jenis Surat</td>
                <td>:</td>
                <td colspan="3"><input type="text" name ="keterangan"id="keterangan" value="<?php echo $row->keterangan; ?>" placeholder="input nama jenis surat" class="validate[required] text-input">
                </td>
            </tr>
            <tr>
                <td colspan="5" align="center">
                    <input type="submit" value="Submit"/>
                    <input type="reset" value="Reset"/>
                </td>
            </tr>
        </table>
        <input type="hidden" name="kdupd" value="<?php echo $kdupd; ?>">
    </form>
    <br>
    <a href="index.php">Lihat Data</a>
</center>
</body>