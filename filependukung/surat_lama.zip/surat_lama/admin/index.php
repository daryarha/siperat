<?php
session_start();
if (!isset($_SESSION['username'])) {
    ?>
    <script type="text/javascript">document.location='../index.php'</script>
    <?php
}
if ($_SESSION['id_priv'] != 1) {
    echo "<script type='text/javascript'>document.location='../index.php'</script>";
}
?>
<body>
<center>
    <h2>Selamat datang <?php echo $_SESSION['username']; ?></h2>

    <a href="master/user/">Master User (Petugas)</a><br>
    <a href="master/jenis_surat/">Master Jenis Surat</a><br>
    <a href="master/pengirim/">Master Pengirim</a><br>
    <a href="../logout.php">Logout</a>
</center>
</body>