<?php
if(empty($_GET['nim'])){
  ?>
  <center>
  <h3>Masukkan NIM Anda untuk melihat data nomor surat</h3>
    <form action="" method="GET">    
        NIM: <input type="text" name="nim" />
        <input type="submit" value="submit" />
    </form>
    <a href='index.php?page=index'>Home</a>
  </center>
  <?php
}
else{
    $nim=$_GET['nim'];
 ?>
<head>
    <link rel="stylesheet" href="tablesorter/style.css" type="text/css" media="print, projection, screen" />
    <script type="text/javascript" src="tablesorter/jquery-latest.js"></script>
    <script type="text/javascript" src="tablesorter/jquery.tablesorter.js"></script>
    <script type="text/javascript" src="tablesorter/jquery.tablesorter.pager.js"></script>

    <script type="text/javascript">
        $(function() {
            $("table")
            .tablesorter({widthFixed: true, widgets: ['zebra'],
                headers: {
                    // assign the secound column (we start counting zero)
                    4: {
                        // disable it by setting the property sorter to false
                        sorter: false
                    },
                    11: {
                        // disable it by setting the property sorter to false
                        sorter: false
                    }
                    
                }})
            .tablesorterPager({container: $("#pager"),positionFixed: false });
        });
    </script>
    <script type="text/javascript">

        function conf(){
            if(confirm("Anda Yakin ?")){
                return true;

            }else{
                window.close();
                return false;
            }
        }
    </script>
</head>
<body>
<center><h2>Data Surat Keluar</h2>
    <hr>
    
<?php
include 'connection.php';
$sql = "SELECT a.id_surat_keluar as idSuratKeluar, a.tanggal, 
b.keterangan AS jenisSurat, a.perihal, a.lampiran, a.keterangan, c.nama_jenis_penerima as penerima, 
d.keterangan AS pengirim,a.nama_pemohon,a.nim_pemohon,a.no_hp_pemohon, e.ket_status_arsip, a.nama_penerima, a.nama_acara, a.id_status_surat
FROM tabel_surat_keluar a, tabel_jenis_surat b, tabel_jenis_penerima c, tabel_pengirim d, tabel_status_arsip e
WHERE a.id_jenis_surat = b.id_jenis_surat
AND a.id_jenis_penerima = c.id_jenis_penerima
AND a.id_pengirim = d.id_pengirim
AND a.id_status_arsip = e.id_status_arsip
AND a.nim_pemohon = '$nim' order by a.tanggal desc;";
$query = mysqli_query($con,$sql) or die(mysqli_error($con));
$no = 1;

function get_no_surat($id_surat){
    $sql="SELECT nomor_surat FROM tabel_no_surat_keluar WHERE id_surat='$id_surat'";
    $query = mysqli_query($con, $sql) or die(mysqli_error($con));
    $result = mysqli_fetch_row($query);
    return $result[0];
}
if (mysql_num_rows($query) > 0) {
    ?>
    <h4>List permohonan surat <?php echo $nim;?><br />
    </h4>
</center>
    <table class="tablesorter" cellspacing="1" >
        <thead>
            <tr>
                <th rowspan="2">No</th>
                <th rowspan="2">Tanggal</th>
                <th rowspan="2">No Surat</th>
                <th rowspan="2">Pengirim</th>
                <th rowspan="2">Nama Acara</th>
                <th colspan="2"><center>Pemohon</center></th>
    <th rowspan="2">Jenis Surat</th>
    <th rowspan="2">Penerima</th>
    <th rowspan="2">Nama Penerima</th>
    <th rowspan="2">Perihal</th>                
    <th rowspan="2">Lampiran</th>              
    <th rowspan="2">Keterangan</th>
    <th rowspan="2">Arsip</th>
    <th rowspan="2">Status Surat</th>
    </tr>
    <tr>
        <th>Nama</th>
        <!--<th>NIM</th>-->
        <th>No. HP</th>
    </tr>
    </thead>
    <tbody>
        <?php
        while ($row = mysql_fetch_object($query)) {
            ?>
            <tr>
                <td><?php echo $no++ ?></td>
                <td><?php echo $row->tanggal; ?></td>
                <td><?php echo get_no_surat($row->idSuratKeluar); ?></td>
                <td><?php echo $row->pengirim; ?></td>
                <td><?php echo $row->nama_acara; ?></td>
                <td><?php echo $row->nama_pemohon; ?></td>
                <!--<td><?php echo $row->nim_pemohon; ?></td>-->
                <td><?php echo $row->no_hp_pemohon; ?></td>
                <td><?php echo $row->jenisSurat; ?></td>
                <td><?php echo $row->penerima; ?></td>
                <td><?php echo $row->nama_penerima; ?></td>
                <td><?php echo $row->perihal; ?></td>
                <td><?php echo $row->lampiran; ?></td>
                <td><?php echo $row->keterangan; ?></td>
                <td><?php echo $row->ket_status_arsip; ?></td>
                <td><?php $stat=$row->id_status_surat;
                    if($stat==0)echo '<font style="color:orange">Diproses</font>';
                    else if($stat==1)echo '<font style="color:green">Disetujui</font>';
                    else if($stat==2)echo '<font style="color:red">Ditolak</font>';
                    ?>
                </td>
            </tr>
            <?php
        }
        ?>
    </tbody>

    </table>
    <div id="pager" class="pager" align="">
        <form>
            <img src="tablesorter/img/first.gif" class="first"/>
            <img src="tablesorter/img/prev.gif" class="prev"/>
            <input type="text" class="pagedisplay"/>
            <img src="tablesorter/img/next.gif" class="next"/>
            <img src="tablesorter/img/last.gif" class="last"/>
            <select class="pagesize">
                <option value="10" selected="selected">10</option>

                <option value="20">20</option>
                <option value="30">30</option>
                <option  value="40">40</option>
                <option  value="50">50</option>
                <option  value="100">100</option>
            </select>
        </form>
    </div>
    <center><a href='index.php?page=index'>Home</a> | <a href='lihat_surat_keluar.php'>Lihat menggunakan NIM lain</a></center>
    
    </body>
    <?php
} else {
    echo "<br>";
    echo "<center>";
    echo "Data tidak ada<br>";
    echo "<a href='index.php?page=index'>Home</a> | <a href='lihat_surat_keluar.php'>Lihat menggunakan NIM lain</a>";
    echo "</center>";
}

}// cek NIM
?>
