<?php

session_start();
include 'connection.php';

$uname = $_POST['username'];
$pass = $_POST['password'];

// $uname = mysqli_real_escape_string(stripslashes($uname));
// $pass = mysqli_real_escape_string(stripslashes($pass));


$querypriv = mysqli_query($con,"SELECT id_priv FROM tabel_user WHERE username =  '$uname'") or die(mysqli_error($con));
$fetchpriv = mysqli_fetch_array($querypriv);
$id_priv = $fetchpriv['id_priv'];

if ($id_priv == "") {
    header('Location:index.php?login=gagal');
}
$query = mysqli_query($con,"select * from tabel_user where username='$uname' and password='$pass' and id_priv=$id_priv") or die(mysqli_error($con));

$fetch = mysqli_fetch_array($query);

if (($uname == $fetch['username']) && ($pass == $fetch['password'])) {
    $_SESSION['username'] = $uname;
    $_SESSION['id_priv'] = $id_priv;

    if ($_SESSION['id_priv'] == 1) {
        header('Location:admin/index.php');
    } else if ($_SESSION['id_priv'] == 2) {
        header('Location:petugas/suratkeluar/index.php');
    } else if ($_SESSION['id_priv'] == 3) {
        header('Location:petugas/suratmasuk/index.php');
    }
} else {
    header('Location:index.php?login=gagal');
}
?>
