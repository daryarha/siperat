<?php
$host = "localhost";
$user = "root";
$pass = "";
$database = "db_bemtiik";
// $conn = mysql_connect();
$con = mysqli_connect($host, $user, $pass, $database)
// mysql_select_db($database, $conn);
?>
