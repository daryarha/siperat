<?php

session_start();
include 'connection.php';

$nama = $_POST['nama'];
$nim = $_POST['nim'];
$hp = $_POST['hp'];

$nama = mysqli_real_escape_string($con,stripslashes($nama));
$nim = mysqli_real_escape_string($con,stripslashes($nim));
$hp = mysqli_real_escape_string($con,stripslashes($hp));

if (isset($nama) && isset($nim) && isset($hp)) {
    $_SESSION['nama'] = $nama;
    $_SESSION['nim'] = $nim;
    $_SESSION['hp'] = $hp;
    header('Location:index.php?page=permohonan');
} else {
    header('Location:index.php?page=index');
}
?>
