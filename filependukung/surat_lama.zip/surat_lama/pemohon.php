<?php
session_start();

if (isset($_SESSION['nama']) && isset($_SESSION['nim']) && isset($_SESSION['hp'])) {
    header('Location:index.php?page=permohonan');
}

?>  
<body>
<center>
    <form id="login" method="post" action="act_pemohon.php">
        <h2>Permohonan Nomor Surat<br />Badan Eksekutif Mahasiswa Teknologi Informasi dan Ilmu Komputer</h2>
        <hr>
        <table>
            <tr>
                <td>Nama Lengkap</td>
                <td>:</td>
                <td><input type="text" name="nama"></td>
            </tr>
            <tr>
                <td>NIM</td>
                <td>:</td>
                <td><input type="text" name="nim"></td>
            </tr>
            <tr>
                <td>Nomor HP</td>
                <td>:</td>
                <td><input type="text" name="hp"></td>
            </tr>
            <tr><td><a href='lihat_surat_keluar.php'>Lihat Permohonan</a></td><td colspan="2" align="right"><input type="submit" value="Masuk"></td></tr>
        </table>


    </form>
    <h3>Format Berkas atau Surat dapat dilihat di <a href="/admin" target="_blank">Profile Admin</a></h3>
</center>
</body>