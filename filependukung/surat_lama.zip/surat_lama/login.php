<?php
session_start();

if (isset($_SESSION['username']) && ($_SESSION['id_priv'] == 1)) {
    ?>
    <script type="text/javascript">document.location='admin/index.php'</script>
    <?php
} else if (isset($_SESSION['username']) && ($_SESSION['id_priv'] == 2)) {
    ?>
    <script type="text/javascript">document.location='petugas/suratkeluar/index.php'</script>

    <?php
} else if (isset($_SESSION['username']) && ($_SESSION['id_priv'] == 3)) {
    ?>
    <script type="text/javascript">document.location='petugas/suratmasuk/index.php'</script>
    <?php
}
?>  
<body>
<center>
    <form id="login" method="post" action="act_login.php">
        <h2>Login</h2>
        <hr>
        <table>
            <tr>
                <td>Username</td>
                <td>:</td>
                <td><input type="text" name="username"></td>
            </tr>
            <tr>
                <td>Password</td>
                <td>:</td>
                <td><input type="password" name="password"></td>
            </tr>
            <tr><td colspan="3" align="right"><input type="submit" value="Login"></td></tr>
        </table>


    </form>
</center>
</body>